package com.best_restaurants.config;

public final class Constants {

    private Constants() {}

    public static final Integer RESTAURANTS_LIST_MAX_SIZE = 5;

}
