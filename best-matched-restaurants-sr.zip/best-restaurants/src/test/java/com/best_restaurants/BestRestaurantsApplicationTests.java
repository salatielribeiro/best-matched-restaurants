package com.best_restaurants;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BestRestaurantsApplicationTests {

	@Test
	void contextLoads() {
	}

}
